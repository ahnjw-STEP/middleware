/* hal.h — HAL Manager 인터페이스 (플랫폼 독립) */
#ifndef HAL_H
#define HAL_H

#include "middleware_types.h"    /* THPSensorData_t, CommandData_t */
#include "middleware_errors.h"   /* MW_OK, MW_ERR_*, HAL_ERR_* */

/* 반환값 규칙: 0 = 성공, 음수 = 오류 코드 */
int  hal_init(const char *config_path);                                /* MW_OK / MW_ERR_CONFIG / HAL_ERR_I2C / HAL_ERR_GPIO / HAL_ERR_UNSUPPORTED_MODEL */
int  hal_thp_sensor_read(const char *sensor_id, THPSensorData_t *out); /* MW_OK / MW_ERR_INVALID_PARAM / MW_ERR_NOT_INITIALIZED / HAL_ERR_I2C */
int  hal_actuator_write(const char *actuator_id, int value);           /* MW_OK / MW_ERR_INVALID_PARAM / MW_ERR_NOT_INITIALIZED / HAL_ERR_GPIO */
void hal_cleanup(void);

#endif /* HAL_H */
