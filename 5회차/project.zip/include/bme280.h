/* bme280.h — BME280 센서 드라이버 인터페이스 (I2C 통신·보정 계산을 캡슐화) */
#ifndef BME280_H
#define BME280_H

/* 칩 ID 확인 → 보정계수 읽기 → 측정 모드 설정 */
int bme280_init(int i2c_handle);                                                           /* MW_OK / HAL_ERR_UNSUPPORTED_MODEL */

/* 온도(°C)·기압(hPa)·습도(%)를 한 번에 읽어 반환 */
int bme280_read(int i2c_handle, double *temperature, double *pressure, double *humidity); /* MW_OK / HAL_ERR_I2C */

#endif /* BME280_H */
