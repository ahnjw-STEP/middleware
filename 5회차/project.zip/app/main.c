/* main.c — HAL 동작 확인 (LED 점멸 + 센서 1회 읽기) */
#include "hal.h"
#include <stdio.h>
#include <unistd.h>

int main(void) {
    if (hal_init("gateway.conf") != MW_OK) {
        fprintf(stderr, "hal_init 실패\n");
        return 1;
    }

    /* 1) 액추에이터 확인: LED를 3번 점멸 
         (액추에이터 ID는 "LED-01"로 설정되어 있다고 가정) */
    for (int i = 0; i < 3; i++) {
        hal_actuator_write("LED-01", 1); sleep(1);
        hal_actuator_write("LED-01", 0); sleep(1);
    }

    /* 2) 센서 확인: 1회 읽어 출력 
         (센서 ID는 "ENV-01"로 설정되어 있다고 가정) */
    THPSensorData_t data;
    if (hal_thp_sensor_read("ENV-01", &data) == MW_OK) {
        printf("T=%.2f C  H=%.1f %%  P=%.1f hPa  (ts=%lld)\n",
               data.temperature, data.humidity, data.pressure,
               (long long)data.timestamp);
    } else {
        fprintf(stderr, "센서 읽기 실패\n");
    }

    hal_cleanup();
    return 0;
}
