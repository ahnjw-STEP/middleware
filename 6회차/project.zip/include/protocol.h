/* protocol.h - Protocol Manager 인터페이스 (클라우드·관제서버와의 통신 추상화) */
#ifndef PROTOCOL_H
#define PROTOCOL_H

#include "middleware_types.h"

/* 설정 파일을 읽고 MQTT 브로커에 연결. 명령 구독 토픽 등록도 함께 처리 */
int  protocol_init(const char *config_path);

/* THP 센서 데이터를 JSON으로 직렬화하여 센서 토픽에 발행. 응용 프로그램은 토픽을 지정하지 않음 */
int  protocol_publish_thp_sensor(const THPSensorData_t *data);

/* 제어 명령 수신 시 호출될 핸들러 등록(내부적으로 commands/+ 와일드카드 구독) */
int  protocol_subscribe_command(void (*handler)(const CommandData_t *));

/* MQTT 연결 종료 및 libmosquitto 자원 해제 */
void protocol_cleanup(void);

#endif /* PROTOCOL_H */
