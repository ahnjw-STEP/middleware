/* storeforward.h - StoreForward Manager 인터페이스 (미전송 데이터의 로컬 저장 전담) */
#ifndef STOREFORWARD_H
#define STOREFORWARD_H

#include "middleware_types.h"

/* DB 오픈 */
int snf_init(const char *db_path);

/* DB에 미전송 데이터 저장 */
int snf_store_pending_thp(const THPSensorData_t *data);

/* DB를 읽어 재전송 대기 데이터 획득  */
int snf_get_pending_thp(THPSensorData_t *buf, int max_count);

/* DB에서 재전송 성공 데이터 삭제 */
int snf_delete_pending(const char *sensor_id, int64_t timestamp);

void snf_cleanup(void);

#endif /* STOREFORWARD_H */
