/* middleware_errors.h - 미들웨어 공용 반환값(오류 코드) 정의 */
#ifndef MIDDLEWARE_ERRORS_H
#define MIDDLEWARE_ERRORS_H

/* 반환값 규칙 : 0 = 성공, 음수 = 오류. 모듈별 범위로 오류 발생 지점을 구분 */
#define MW_OK                       0

/* 공통 오류 (-1 ~ -9) */
#define MW_ERR_INVALID_PARAM       -1   /* 잘못된 파라미터 */
#define MW_ERR_NOT_INITIALIZED     -2   /* 초기화 전 호출(사전조건 위반) */
#define MW_ERR_CONFIG              -3   /* 설정 파일 오류 */

/* HAL Manager 오류 (-10 ~ -19) */
#define HAL_ERR_I2C                -10  /* I2C 오류(열기·통신) */
#define HAL_ERR_GPIO               -11  /* GPIO 오류(초기화·쓰기) */
#define HAL_ERR_UNSUPPORTED_MODEL  -12  /* 미지원 모델 */

/* Protocol Manager 오류 (-20 ~ -29) */
#define PROTO_ERR_BROKER           -20  /* 브로커 연결 실패 */
#define PROTO_ERR_PUBLISH_STORED   -21  /* 발행 실패, StoreForward에 저장 성공(데이터 보존) */
#define PROTO_ERR_PUBLISH_LOST     -22  /* 발행·저장 모두 실패(데이터 손실) */

/* StoreForward Manager 오류 (-30 ~ -39) */
#define SNF_ERR_DB_OPEN            -30  /* DB 열기 실패 */
#define SNF_ERR_DB_WRITE           -31  /* DB 쓰기 실패 */
#define SNF_ERR_DB_QUERY           -32  /* DB 조회 오류 */
#define SNF_ERR_NOT_FOUND          -33  /* 삭제 대상 없음 */

#endif /* MIDDLEWARE_ERRORS_H */
