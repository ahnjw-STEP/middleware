/* middleware_types.h - 공통 데이터 구조체 정의 */
#ifndef MIDDLEWARE_TYPES_H
#define MIDDLEWARE_TYPES_H

#include <stdint.h>

/* THP(온도·습도·기압) 측정 항목 비트 플래그 (valid_fields에 사용) */
#define THP_FIELD_TEMPERATURE  0x01  /* 온도 유효 */
#define THP_FIELD_HUMIDITY     0x02  /* 습도 유효 */
#define THP_FIELD_PRESSURE     0x04  /* 기압 유효 */

/* THP 센서 데이터 구조체 (Temperature·Humidity·Pressure) */
typedef struct {
    char     sensor_id[16];  /* 센서 식별자 (예: "ENV-01") */
    float    temperature;    /* 온도 (단위: 섭씨) */
    float    humidity;       /* 습도 (단위: %) */
    float    pressure;       /* 기압 (단위: hPa) */
    uint8_t  valid_fields;   /* 유효 측정 항목 비트마스크 (예: 온도·습도·기압=0x07, 온도·습도=0x03) */
    int64_t  timestamp;      /* 측정 시점의 Unix 타임스탬프 (HAL이 센서를 읽는 순간 기록) */
} THPSensorData_t;

/* 제어 명령 구조체 */
typedef struct {
    char     actuator_id[16]; /* 액추에이터 식별자 (예: "LED-01") */
    int      value;           /* 제어값: 0 = OFF, 1 = ON */
    int64_t  timestamp;       /* 명령 수신 시각의 Unix 타임스탬프 */
} CommandData_t;

#endif /* MIDDLEWARE_TYPES_H */
