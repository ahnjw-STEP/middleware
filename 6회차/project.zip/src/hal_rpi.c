/* hal_rpi.c - 라즈베리파이 실제 하드웨어 인터페이스 구현 */
#include "hal.h"
#include "bme280.h"
#include <lgpio.h>
#include <ini.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

/* GPIO 칩 번호: 라즈베리파이 5는 40핀 헤더가 RP1에 연결됨.
   현재 Raspberry Pi OS에서는 gpiochip0, 커널 버전에 따라 gpiochip4일 수 있으므로
   gpiodetect 명령으로 확인 후 조정한다. */
#define GATEWAY_GPIOCHIP     0

/* -- 내부 상태 변수 -- */
static int  g_chip  = -1;          /* lgGpiochipOpen 핸들 */
static int  g_i2c   = -1;          /* lgI2cOpen 핸들 */
static int  g_gpio  = -1;          /* 액추에이터 GPIO (BCM) */
static char g_sensor_id[16];
static char g_actuator_id[16];

/* 설정 파일에서 읽어들인 게이트웨이 구성 */
typedef struct {
    char sensor_id[16];
    int  i2c_bus;
    int  i2c_addr;
    char actuator_id[16];
    int  gpio;
} gw_config_t;

/* inih 콜백 : gateway.conf의 [섹션] 안 key=value를 만날 때마다 호출됨 */
static int conf_handler(void *user, const char *section,
                        const char *name, const char *value) {
    gw_config_t *c = (gw_config_t *)user;
    if (strncmp(section, "sensor:", 7) == 0) {            /* [sensor:ENV-01] */
        if (strlen(section + 7) >= sizeof(c->sensor_id))
            return 0;    /* sensor_id가 버퍼(15자)보다 길면 파싱 중단 */
        strncpy(c->sensor_id, section + 7, sizeof(c->sensor_id) - 1);
        c->sensor_id[sizeof(c->sensor_id) - 1] = '\0';
        if (strcmp(name, "i2c_bus") == 0) {
            const char *dash = strrchr(value, '-');        /* "/dev/i2c-1" → 1 */
            c->i2c_bus = dash ? atoi(dash + 1) : atoi(value);
        } else if (strcmp(name, "i2c_addr") == 0) {
            c->i2c_addr = (int)strtol(value, NULL, 16);    /* "0x76" → 0x76 */
        }
    } else if (strncmp(section, "actuator:", 9) == 0) {   /* [actuator:LED-01] */
        if (strlen(section + 9) >= sizeof(c->actuator_id))
            return 0;  /* actuator_id가 버퍼(15자)보다 길면 파싱 중단 */
        strncpy(c->actuator_id, section + 9, sizeof(c->actuator_id) - 1);
        c->actuator_id[sizeof(c->actuator_id) - 1] = '\0';
        if (strcmp(name, "gpio") == 0) {
            c->gpio = atoi(value);                         /* "17" → 17 */
        }
    }
    return 1;   /* 0을 반환하면 파싱을 중단(오류)함 */
}
/* (계속) hal_rpi.c - 라즈베리파이 실제 하드웨어 인터페이스 구현 */

int hal_init(const char *config_path) {
    /* 1) 설정 파일 파싱 - inih가 [섹션]과 key=value를 분리해 conf_handler로 전달 */
    gw_config_t cfg = { .i2c_bus = -1, .i2c_addr = -1, .gpio = -1 };
    
    if (ini_parse(config_path, conf_handler, &cfg) != 0)
        return MW_ERR_CONFIG;       /* 파일 없음·파싱 실패 */
    if (cfg.i2c_bus < 0 || cfg.i2c_addr < 0 || cfg.gpio < 0)
        return MW_ERR_CONFIG;   /* 필수 키 누락 */
    
    strncpy(g_sensor_id,   cfg.sensor_id,   sizeof(g_sensor_id) - 1);
    g_sensor_id[sizeof(g_sensor_id) - 1] = '\0';
    strncpy(g_actuator_id, cfg.actuator_id, sizeof(g_actuator_id) - 1);
    g_actuator_id[sizeof(g_actuator_id) - 1] = '\0';
    
    g_gpio = cfg.gpio;

    /* 2) GPIO 칩 열기 (RP1: 40핀 헤더가 연결된 gpiochip) */
    g_chip = lgGpiochipOpen(GATEWAY_GPIOCHIP);
    if (g_chip < 0)
        return HAL_ERR_GPIO;

    /* 3) I2C 버스 열기 */
    g_i2c = lgI2cOpen(cfg.i2c_bus, cfg.i2c_addr, 0);
    if (g_i2c < 0) {
        lgGpiochipClose(g_chip);
        g_chip = -1;
        return HAL_ERR_I2C;
    }

    /* 4) BME280 관련 초기화 (bme280.c에 캡슐화됨) */
    int bme_r = bme280_init(g_i2c);
    if (bme_r != MW_OK) {
        lgI2cClose(g_i2c);
        g_i2c = -1;
        lgGpiochipClose(g_chip);
        g_chip = -1;
        return bme_r;
    }

    /* 5) 액추에이터 GPIO를 출력으로 확보(초기값 0) */
    if (lgGpioClaimOutput(g_chip, 0, g_gpio, 0) < 0) {
        lgI2cClose(g_i2c);
        g_i2c = -1;
        lgGpiochipClose(g_chip);
        g_chip = -1;
        return HAL_ERR_GPIO;
    }
    return MW_OK;
}
/* (계속) hal_rpi.c - 라즈베리파이 실제 하드웨어 인터페이스 구현 */

int hal_actuator_write(const char *actuator_id, int value) {
    if (actuator_id == NULL)
        return MW_ERR_INVALID_PARAM;
    if (g_chip < 0)
        return MW_ERR_NOT_INITIALIZED;   /* hal_init 미호출 또는 실패 */
    if (strcmp(actuator_id, g_actuator_id) != 0)
        return MW_ERR_INVALID_PARAM;   /* 미등록 actuator_id */
    if (lgGpioWrite(g_chip, g_gpio, value ? 1 : 0) < 0)
        return HAL_ERR_GPIO;   /* GPIO 쓰기 실패 */
    return MW_OK;
}

void hal_cleanup(void) {
    if (g_i2c  >= 0)
        lgI2cClose(g_i2c);
    if (g_chip >= 0)
        lgGpiochipClose(g_chip);
}
/* (계속) hal_rpi.c - 라즈베리파이 실제 하드웨어 인터페이스 구현 */

int hal_thp_sensor_read(const char *sensor_id, THPSensorData_t *out) {
    if (sensor_id == NULL || out == NULL)
        return MW_ERR_INVALID_PARAM;
    if (g_i2c < 0)
        return MW_ERR_NOT_INITIALIZED;   /* hal_init 미호출 또는 실패 */
    if (strcmp(sensor_id, g_sensor_id) != 0)
        return MW_ERR_INVALID_PARAM;   /* 미등록 sensor_id */

    double temperature, pressure, humidity;
    int bme_r = bme280_read(g_i2c, &temperature, &pressure, &humidity);
    if (bme_r != MW_OK)
        return bme_r;                      /* I2C 통신 오류 등 */

    strncpy(out->sensor_id, sensor_id, sizeof(out->sensor_id) - 1);
    out->sensor_id[sizeof(out->sensor_id) - 1] = '\0';
    out->temperature  = (float)temperature;
    out->pressure     = (float)pressure;
    out->humidity     = (float)humidity;
    out->valid_fields = THP_FIELD_TEMPERATURE | THP_FIELD_HUMIDITY | THP_FIELD_PRESSURE;
    out->timestamp    = (int64_t)time(NULL);               /* 측정 시각 = 읽는 순간 */
    return MW_OK;
}
