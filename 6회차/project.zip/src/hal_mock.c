/* hal_mock.c - 하드웨어 없이 상위 계층을 개발·테스트하기 위한 Mock 구현 */
#include "hal.h"
#include <stdio.h>
#include <string.h>
#include <time.h>

int hal_init(const char *config_path) {
    (void)config_path;                 /* 컴파일러 경고 출력 억제 */
    printf("[MOCK] hal_init\n");
    return MW_OK;
}

int hal_thp_sensor_read(const char *sensor_id, THPSensorData_t *out) {
    if (sensor_id == NULL || out == NULL)
        return MW_ERR_INVALID_PARAM;
    strncpy(out->sensor_id, sensor_id, sizeof(out->sensor_id) - 1);
    out->sensor_id[sizeof(out->sensor_id) - 1] = '\0';
    
    /* 고정된 가상의 값 */
    out->temperature  = 25.0f;         
    out->humidity     = 50.0f;
    out->pressure     = 1013.2f;
    out->valid_fields = THP_FIELD_TEMPERATURE | THP_FIELD_HUMIDITY | THP_FIELD_PRESSURE;
    out->timestamp    = (int64_t)time(NULL);
    
    return MW_OK;
}

int hal_actuator_write(const char *actuator_id, int value) {
    if (actuator_id == NULL)
        return MW_ERR_INVALID_PARAM;
    printf("[MOCK] actuator %s <- %d\n", actuator_id, value);
    return MW_OK;
}

void hal_cleanup(void) {
    printf("[MOCK] hal_cleanup\n");
}
