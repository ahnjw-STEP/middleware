/* protocol.c - Protocol Manager 구현 (libmosquitto 래핑) #1a : 설정 파싱 */
#include "protocol.h"
#include "storeforward.h"
#include "middleware_errors.h"
#include <mosquitto.h>
#include <ini.h>
#include <cjson/cJSON.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

/* -- 내부 상태 (이 파일 안에서만 사용) -- */
static struct mosquitto *g_mosq = NULL;                 /* libmosquitto 클라이언트 핸들 */
static void (*g_cmd_handler)(const CommandData_t *) = NULL;  /* 응용 프로그램이 등록한 명령 핸들러 */
static volatile int g_connected = 0;                    /* 브로커 연결 상태(콜백이 갱신) */
static char g_sub_topic[160];                           /* 명령 구독 토픽(commands/+). 초기화 시 1회 조합해 두고
                                                            on_connect가 연결될 때마다 이 값으로 구독한다 */

/* gateway.conf에서 읽어들인 통신 설정을 담을 구조체 */
static struct {
    char gw_id[32];
    char broker_host[64];
    int  broker_port;
    int  qos;
    int  keepalive;
    int  reconnect_interval;      /* 재연결 시도 간격(초) */
    char sensor_template[128];    /* factory/{gw_id}/sensors/{sensor_type} */
    char command_template[128];   /* factory/{gw_id}/commands/{actuator_id} */
    char db_path[128];            /* StoreForward용 SQLite 경로 */
} g_cfg;

/* 설정 파일 파싱(inih 콜백) : 섹션별로 필요한 값만 g_cfg에 담음 */
static int conf_handler(void *user, const char *section,
                        const char *name, const char *value) {
    (void)user;
    if (strcmp(section, "device") == 0) {
        if (strcmp(name, "gw_id") == 0)
            strncpy(g_cfg.gw_id, value, sizeof(g_cfg.gw_id) - 1);
    } else if (strcmp(section, "mqtt") == 0) {
        if (strcmp(name, "broker_host") == 0)
            strncpy(g_cfg.broker_host, value, sizeof(g_cfg.broker_host) - 1);
        else if (strcmp(name, "broker_port") == 0)
            g_cfg.broker_port = atoi(value);
        else if (strcmp(name, "qos") == 0)
            g_cfg.qos = atoi(value);
        else if (strcmp(name, "keepalive") == 0)
            g_cfg.keepalive = atoi(value);
        else if (strcmp(name, "reconnect_interval") == 0)
            g_cfg.reconnect_interval = atoi(value);
    } else if (strcmp(section, "topic") == 0) {
        if (strcmp(name, "sensor_template") == 0)
            strncpy(g_cfg.sensor_template, value, sizeof(g_cfg.sensor_template) - 1);
        else if (strcmp(name, "command_template") == 0)
            strncpy(g_cfg.command_template, value, sizeof(g_cfg.command_template) - 1);
    } else if (strcmp(section, "storage") == 0) {
        if (strcmp(name, "db_path") == 0)
            strncpy(g_cfg.db_path, value, sizeof(g_cfg.db_path) - 1);
    }
    return 1;
}

/* 토픽 템플릿의 자리표시자({gw_id}, {sensor_type} 등)를 실제 값으로 1회 치환 */
static void fill_placeholder(char *out, size_t out_sz,
                             const char *template_str,
                             const char *key, const char *val) {
    const char *pos = strstr(template_str, key);
    if (pos == NULL) {
        strncpy(out, template_str, out_sz - 1);
        out[out_sz - 1] = '\0';
        return;
    }
    size_t head = (size_t)(pos - template_str);
    snprintf(out, out_sz, "%.*s%s%s",
             (int)head, template_str, val, pos + strlen(key));
}
/* protocol.c - Protocol Manager 구현 (libmosquitto 래핑) #1b : 연결·구독 */

/* -- 연결 상태 콜백 --
   백그라운드 루프가 브로커와의 연결·단절을 감지할 때마다 호출된다.
   발행 함수는 이 상태(g_connected)를 보고 발행할지 즉시 저장할지 결정한다. */
static void on_connect(struct mosquitto *mosq, void *userdata, int rc) {
    (void)userdata;
    g_connected = (rc == 0) ? 1 : 0;
    if (g_connected) {
        /* 클라이언트가 clean session이라 재연결마다 브로커 쪽 구독이 사라지므로,
           연결이 확인될 때마다(최초 연결·재연결 모두) 여기서 다시 구독한다 -
           그래야 브로커가 재시작된 뒤에도 명령 수신이 끊기지 않는다. */
        mosquitto_subscribe(mosq, NULL, g_sub_topic, g_cfg.qos);
    }
}

static void on_disconnect(struct mosquitto *mosq, void *userdata, int rc) {
    (void)mosq;
    (void)userdata;
    (void)rc;
    g_connected = 0;
}

/* on_message의 전체 구현은 아래 (4) 명령 수신 처리에서 다룬다. protocol_init이 이 함수를
   mosquitto_message_callback_set에 넘기려면, 정의가 뒤에 오더라도 프로토타입을 미리 선언해
   컴파일러가 이름을 알 수 있게 해야 한다. */
static void on_message(struct mosquitto *mosq, void *userdata,
                        const struct mosquitto_message *msg);

int protocol_init(const char *config_path) {
    /* 1) 설정 파싱 */
    memset(&g_cfg, 0, sizeof(g_cfg));
    g_cfg.qos = 1;
    g_cfg.keepalive = 60;
    g_cfg.reconnect_interval = 5;
    if (ini_parse(config_path, conf_handler, NULL) != 0)
        return MW_ERR_CONFIG;
    if (g_cfg.gw_id[0] == '\0' || g_cfg.broker_host[0] == '\0'
        || g_cfg.sensor_template[0] == '\0' || g_cfg.db_path[0] == '\0')
        return MW_ERR_CONFIG;   /* 필수 항목 누락 */

    /* 2) Store-and-Forward 저장소 초기화(발행 실패 대비 안전망) */
    int snf_r = snf_init(g_cfg.db_path);
    if (snf_r != MW_OK)
        return snf_r;           /* 저장소를 못 열면 안전망이 없으므로 초기화 실패로 처리 */

    /* 3) 통신 라이브러리 초기화·클라이언트 생성 */
    mosquitto_lib_init();
    g_mosq = mosquitto_new(g_cfg.gw_id, true, NULL);    /* Client ID = gw_id */
    if (g_mosq == NULL) {
        snf_cleanup();
        return PROTO_ERR_BROKER;
    }
    mosquitto_connect_callback_set(g_mosq, on_connect);
    mosquitto_disconnect_callback_set(g_mosq, on_disconnect);
    mosquitto_message_callback_set(g_mosq, on_message);
    /* reconnect_interval초 간격으로 자동 재연결(고정 간격 - exponential backoff 미사용이므로
       delay_max 인자는 참조되지 않아 delay와 동일한 값을 넘김) */
    mosquitto_reconnect_delay_set(g_mosq, g_cfg.reconnect_interval,
                                  g_cfg.reconnect_interval, false);

    /* 4) 구독할 명령 토픽을 미리 조합해 둔다 - 실제 구독은 on_connect에서 수행하므로
       여기서는 문자열만 준비한다(commands/+ 와일드카드로 모든 액추에이터 명령을 일괄 구독) */
    char cmd_topic[128];
    fill_placeholder(cmd_topic, sizeof(cmd_topic),
                     g_cfg.command_template, "{gw_id}", g_cfg.gw_id);
    fill_placeholder(g_sub_topic, sizeof(g_sub_topic), cmd_topic, "{actuator_id}", "+");

    /* 5) 브로커 연결 */
    if (mosquitto_connect(g_mosq, g_cfg.broker_host, g_cfg.broker_port,
                          g_cfg.keepalive) != MOSQ_ERR_SUCCESS) {
        mosquitto_destroy(g_mosq);
        g_mosq = NULL;
        mosquitto_lib_cleanup();
        snf_cleanup();
        return PROTO_ERR_BROKER;
    }

    /* 6) 네트워크 처리·재연결·콜백을 담당하는 백그라운드 루프 시작 */
    mosquitto_loop_start(g_mosq);

    /* 연결 수립(CONNACK 수신 → on_connect 호출, 이 안에서 구독까지 완료)을 잠시
       기다린다. mosquitto_connect()는 바로 위에서 이미 성공했으므로, 여기서
       기다리는 것은 CONNACK이 오는 시점의 지연뿐이다. 최대 약 2초 대기하며,
       그 안에 연결되지 않아도 초기화 자체는 성공으로 둔다(이후 발행은 상태를
       보고 저장 경로로 우회하고, on_connect는 뒤늦게라도 실제로 연결되는
       시점에 호출되어 그때 구독까지 완료한다). */
    for (int i = 0; i < 20 && !g_connected; i++) {
        struct timespec ts = { 0, 100 * 1000 * 1000 };   /* 100ms */
        nanosleep(&ts, NULL);
    }
    return MW_OK;
}
/* protocol.c #2 : 센서 데이터 발행 */

/* 유효한 측정 항목 하나를 토픽·페이로드로 만들어 발행. 반환 : 0 성공 / -1 실패 */
static int publish_one(const char *sensor_id, int64_t timestamp,
                       const char *type, const char *unit, float value) {
    char topic[160];
    char t1[160];
    fill_placeholder(t1, sizeof(t1), g_cfg.sensor_template, "{gw_id}", g_cfg.gw_id);
    fill_placeholder(topic, sizeof(topic), t1, "{sensor_type}", type);

    /* float를 그대로 담으면 float->double 변환 오차가 직렬화에 그대로 드러나
       24.5가 24.500000953674316처럼 나온다. 소수 둘째 자리로 반올림해서 담는다. */
    double rounded_value = round((double)value * 100.0) / 100.0;

    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "gw_id", g_cfg.gw_id);
    cJSON_AddStringToObject(root, "sensor_id", sensor_id);
    cJSON_AddNumberToObject(root, "value", rounded_value);
    cJSON_AddStringToObject(root, "unit", unit);
    cJSON_AddNumberToObject(root, "timestamp", (double)timestamp);

    char *payload = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    if (payload == NULL)
        return -1;

    int rc = mosquitto_publish(g_mosq, NULL, topic,
                               (int)strlen(payload), payload, g_cfg.qos, false);
    free(payload);
    return (rc == MOSQ_ERR_SUCCESS) ? 0 : -1;
}

int protocol_publish_thp_sensor(const THPSensorData_t *data) {
    if (data == NULL)
        return MW_ERR_INVALID_PARAM;
    if (g_mosq == NULL)
        return MW_ERR_NOT_INITIALIZED;

    /* 브로커와 연결되어 있지 않으면 발행을 시도하지 않고 곧바로 저장한다.
       (연결이 끊긴 상태에서도 mosquitto_publish()는 성공을 반환하므로,
        연결 상태를 먼저 확인하는 것이 데이터 보존의 관건이다.) */
    if (!g_connected) {
        if (snf_store_pending_thp(data) == MW_OK)
            return PROTO_ERR_PUBLISH_STORED;   /* 데이터 보존됨 */
        else
            return PROTO_ERR_PUBLISH_LOST;     /* 저장까지 실패 → 데이터 손실 */
    }

    int failed = 0;
    /* 유효한 측정 항목만 각각 별도 토픽으로 발행 */
    if (data->valid_fields & THP_FIELD_TEMPERATURE)
        failed |= publish_one(data->sensor_id, data->timestamp,
                              "temperature", "celsius", data->temperature);
    if (data->valid_fields & THP_FIELD_HUMIDITY)
        failed |= publish_one(data->sensor_id, data->timestamp,
                              "humidity", "percent", data->humidity);
    if (data->valid_fields & THP_FIELD_PRESSURE)
        failed |= publish_one(data->sensor_id, data->timestamp,
                              "pressure", "hPa", data->pressure);

    if (failed) {
        /* 발행 실패 → StoreForward에 저장 시도 */
        if (snf_store_pending_thp(data) == MW_OK)
            return PROTO_ERR_PUBLISH_STORED;   /* 데이터 보존됨 */
        else
            return PROTO_ERR_PUBLISH_LOST;     /* 저장까지 실패 → 데이터 손실 */
    }
    return MW_OK;
}
/* protocol.c #3 : 명령 수신 처리 */

/* 명령 파싱. JSON 페이로드 예: {"actuator_id":"LED-01","value":1} */
static int parse_command(const char *json, CommandData_t *cmd) {
    cJSON *root = cJSON_Parse(json);
    if (root == NULL)
        return -1;

    const cJSON *aid = cJSON_GetObjectItemCaseSensitive(root, "actuator_id");
    const cJSON *val = cJSON_GetObjectItemCaseSensitive(root, "value");
    if (!cJSON_IsString(aid) || aid->valuestring == NULL || !cJSON_IsNumber(val)) {
        cJSON_Delete(root);
        return -1;                          /* 필수 필드 누락·형식 오류 */
    }

    strncpy(cmd->actuator_id, aid->valuestring, sizeof(cmd->actuator_id) - 1);
    cmd->actuator_id[sizeof(cmd->actuator_id) - 1] = '\0';
    cmd->value = val->valueint;

    cJSON_Delete(root);
    return 0;
}

/* libmosquitto 메시지 수신 콜백 : commands/+ 로 들어온 명령을 핸들러에 전달 */
static void on_message(struct mosquitto *mosq, void *userdata,
                       const struct mosquitto_message *msg) {
    (void)mosq;
    (void)userdata;
    if (g_cmd_handler == NULL || msg->payload == NULL)
        return;

    CommandData_t cmd;
    memset(&cmd, 0, sizeof(cmd));
    if (parse_command((const char *)msg->payload, &cmd) != 0)
        return;                                 /* 형식 오류 명령은 무시 */
    cmd.timestamp = (int64_t)time(NULL);        /* 수신 시각을 직접 기록 */
    g_cmd_handler(&cmd);
}

int protocol_subscribe_command(void (*handler)(const CommandData_t *)) {
    if (handler == NULL)
        return MW_ERR_INVALID_PARAM;
    g_cmd_handler = handler;   /* 실제 구독은 protocol_init에서 완료됨 */
    return MW_OK;
}

void protocol_cleanup(void) {
    if (g_mosq != NULL) {
        /* DISCONNECT 패킷을 먼저 보내고, 루프는 강제 중단(true) 대신
           정상 종료(false)로 세워 그 패킷이 실제로 나갈 시간을 준다 */
        mosquitto_disconnect(g_mosq);
        mosquitto_loop_stop(g_mosq, false);
        mosquitto_destroy(g_mosq);
        g_mosq = NULL;
        mosquitto_lib_cleanup();
    }
    snf_cleanup();
}
