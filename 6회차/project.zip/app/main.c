/* main.c - 데이터 송수신 동작 확인 (센서 발행 + 명령 수신 + 재전송) */
#include "hal.h"
#include "protocol.h"
#include "storeforward.h"
#include <stdio.h>
#include <unistd.h>

/* 관제서버 명령 처리 핸들러. 대상은 페이로드의 actuator_id로 판별되어 넘어온다. */
static void on_command(const CommandData_t *cmd) {
    printf("[CMD] %s <- %d\n", cmd->actuator_id, cmd->value);
    hal_actuator_write(cmd->actuator_id, cmd->value);
}

/* 재전송(forward) : 저장돼 있던 미전송 데이터를 다시 발행하고 성공분을 삭제 */
static void flush_pending(void) {
    THPSensorData_t pending[16];
    int n = snf_get_pending_thp(pending, 16);
    for (int i = 0; i < n; i++) {
        if (protocol_publish_thp_sensor(&pending[i]) == MW_OK) {
            snf_delete_pending(pending[i].sensor_id, pending[i].timestamp);
            printf("[FORWARD] resent & deleted (ts=%lld)\n",
                   (long long)pending[i].timestamp);
        }
    }
}

int main(void) {
    if (hal_init("gateway.conf") != MW_OK) {
        fprintf(stderr, "hal_init 실패\n");
        return 1;
    }
    if (protocol_init("gateway.conf") != MW_OK) {
        fprintf(stderr, "protocol_init 실패\n");
        hal_cleanup();
        return 1;
    }
    protocol_subscribe_command(on_command);

    /* 주기적으로 센서를 읽어 발행 (데모용 테스트 프로그램이므로 1초 간격 무한 반복 -
       Ctrl+C로 종료. 실제 배포 환경의 측정 주기는 gateway.conf의 read_period를 따름) */
    for (;;) {
        THPSensorData_t data;
        if (hal_thp_sensor_read("ENV-01", &data) == MW_OK) {
            int r = protocol_publish_thp_sensor(&data);
            if (r == MW_OK)
                printf("[PUB] T=%.2f H=%.1f P=%.1f published\n",
                       data.temperature, data.humidity, data.pressure);
            else if (r == PROTO_ERR_PUBLISH_STORED)
                printf("[WARN] publish failed, stored to DB (보존됨)\n");
            else if (r == PROTO_ERR_PUBLISH_LOST)
                fprintf(stderr, "[ERROR] publish/store 모두 실패 (데이터 손실)\n");
        }
        flush_pending();   /* 재연결됐다면 밀린 데이터도 함께 재전송 */
        sleep(1);
    }

    /* 무한 반복이므로 이 지점에는 도달하지 않는다 - Ctrl+C(SIGINT)로 종료하면
       프로세스가 즉시 끝나며 아래 정리 호출은 실행되지 않는다. 정식 종료 처리
       (시그널 핸들러 등)는 이 회차의 범위 밖이며, 정상적인 초기화 실패 경로
       (위의 return 1)에서는 hal_cleanup·protocol_cleanup이 호출된다. */
    protocol_cleanup();
    hal_cleanup();
    return 0;
}
