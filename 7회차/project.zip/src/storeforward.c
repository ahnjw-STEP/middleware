/* storeforward.c - StoreForward Manager 구현 (SQLite 래핑) */
#include "storeforward.h"
#include "middleware_errors.h"
#include <sqlite3.h>
#include <string.h>

/* -- 내부 상태 (이 파일 안에서만 사용) -- */
static sqlite3 *g_db = NULL;   /* SQLite 연결 핸들 */

/* (sensor_id, timestamp)를 기본 키로 두어 재전송 성공분을 정확히 특정해 삭제한다. */
static const char *SQL_CREATE =
    "CREATE TABLE IF NOT EXISTS pending_thp ("
    "  sensor_id    TEXT    NOT NULL,"
    "  temperature  REAL,"
    "  humidity     REAL,"
    "  pressure     REAL,"
    "  valid_fields INTEGER NOT NULL,"
    "  timestamp    INTEGER NOT NULL,"
    "  PRIMARY KEY (sensor_id, timestamp)"
    ");";

int snf_init(const char *db_path) {
    if (db_path == NULL)
        return MW_ERR_INVALID_PARAM;

    /* DB 파일 열기(없으면 생성). WAL 모드로 정전 시 손상 위험을 낮춘다. */
    if (sqlite3_open(db_path, &g_db) != SQLITE_OK) {
        sqlite3_close(g_db);   /* 실패해도 핸들 정리 */
        g_db = NULL;
        return SNF_ERR_DB_OPEN;
    }
    sqlite3_exec(g_db, "PRAGMA journal_mode=WAL;", NULL, NULL, NULL);

    /* 테이블이 없으면 생성 */
    if (sqlite3_exec(g_db, SQL_CREATE, NULL, NULL, NULL) != SQLITE_OK) {
        sqlite3_close(g_db);
        g_db = NULL;
        return SNF_ERR_DB_OPEN;
    }
    return MW_OK;
}

int snf_store_pending_thp(const THPSensorData_t *data) {
    if (data == NULL)
        return MW_ERR_INVALID_PARAM;
    if (g_db == NULL)
        return MW_ERR_NOT_INITIALIZED;

    const char *sql =
        "INSERT OR REPLACE INTO pending_thp"
        " (sensor_id, temperature, humidity, pressure, valid_fields, timestamp)"
        " VALUES (?, ?, ?, ?, ?, ?);";

    sqlite3_stmt *stmt = NULL;
    if (sqlite3_prepare_v2(g_db, sql, -1, &stmt, NULL) != SQLITE_OK)
        return SNF_ERR_DB_WRITE;

    /* 값 바인딩(SQL 문자열 조립 대신 바인딩 → SQL 인젝션·형변환 오류 예방) */
    sqlite3_bind_text(stmt, 1, data->sensor_id, -1, SQLITE_TRANSIENT);

    /* valid_fields에 없는 항목은 실제 값 대신 NULL로 저장 → "0.0으로 측정됨"과
       "이 센서는 해당 항목을 제공하지 않음"을 DB 상에서 구분 가능하게 함 */
    if (data->valid_fields & THP_FIELD_TEMPERATURE)
        sqlite3_bind_double(stmt, 2, data->temperature);
    else
        sqlite3_bind_null(stmt, 2);

    if (data->valid_fields & THP_FIELD_HUMIDITY)
        sqlite3_bind_double(stmt, 3, data->humidity);
    else
        sqlite3_bind_null(stmt, 3);

    if (data->valid_fields & THP_FIELD_PRESSURE)
        sqlite3_bind_double(stmt, 4, data->pressure);
    else
        sqlite3_bind_null(stmt, 4);

    sqlite3_bind_int  (stmt, 5, data->valid_fields);
    sqlite3_bind_int64(stmt, 6, data->timestamp);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    if (rc != SQLITE_DONE)
        return SNF_ERR_DB_WRITE;
    return MW_OK;
}

int snf_get_pending_thp(THPSensorData_t *buf, int max_count) {
    if (buf == NULL || max_count <= 0)
        return MW_ERR_INVALID_PARAM;
    if (g_db == NULL)
        return MW_ERR_NOT_INITIALIZED;

    /* 오래된 것부터 재전송하도록 timestamp 오름차순 */
    const char *sql =
        "SELECT sensor_id, temperature, humidity, pressure, valid_fields, timestamp"
        " FROM pending_thp ORDER BY timestamp ASC LIMIT ?;";

    sqlite3_stmt *stmt = NULL;
    if (sqlite3_prepare_v2(g_db, sql, -1, &stmt, NULL) != SQLITE_OK)
        return SNF_ERR_DB_QUERY;
    sqlite3_bind_int(stmt, 1, max_count);

    int n = 0;
    while (n < max_count && sqlite3_step(stmt) == SQLITE_ROW) {
        const unsigned char *sid = sqlite3_column_text(stmt, 0);
        strncpy(buf[n].sensor_id, sid ? (const char *)sid : "",
                sizeof(buf[n].sensor_id) - 1);
        buf[n].sensor_id[sizeof(buf[n].sensor_id) - 1] = '\0';
        buf[n].temperature  = (float)sqlite3_column_double(stmt, 1);
        buf[n].humidity     = (float)sqlite3_column_double(stmt, 2);
        buf[n].pressure     = (float)sqlite3_column_double(stmt, 3);
        buf[n].valid_fields = (uint8_t)sqlite3_column_int(stmt, 4);
        buf[n].timestamp    = (int64_t)sqlite3_column_int64(stmt, 5);
        n++;
    }
    sqlite3_finalize(stmt);
    return n;   /* 담은 항목 수(0이면 대기 데이터 없음) */
}

int snf_delete_pending(const char *sensor_id, int64_t timestamp) {
    if (sensor_id == NULL)
        return MW_ERR_INVALID_PARAM;
    if (g_db == NULL)
        return MW_ERR_NOT_INITIALIZED;

    const char *sql =
        "DELETE FROM pending_thp WHERE sensor_id = ? AND timestamp = ?;";

    sqlite3_stmt *stmt = NULL;
    if (sqlite3_prepare_v2(g_db, sql, -1, &stmt, NULL) != SQLITE_OK)
        return SNF_ERR_DB_QUERY;
    sqlite3_bind_text (stmt, 1, sensor_id, -1, SQLITE_TRANSIENT);
    sqlite3_bind_int64(stmt, 2, timestamp);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    if (rc != SQLITE_DONE)
        return SNF_ERR_DB_QUERY;
    if (sqlite3_changes(g_db) == 0)
        return SNF_ERR_NOT_FOUND;   /* 삭제할 행이 없었음 */
    return MW_OK;
}

void snf_cleanup(void) {
    if (g_db != NULL) {
        sqlite3_close(g_db);
        g_db = NULL;
    }
}
