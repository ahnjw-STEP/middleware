/* bme280.c - BME280 센서 드라이버 (I2C 레지스터·보정 계산을 이 파일 안에 캡슐화) */
#include "bme280.h"
#include "middleware_errors.h"
#include <lgpio.h>
#include <stdint.h>

/* -- BME280 레지스터 주소 (이 파일 밖에서는 알 필요 없음) -- */
#define BME280_REG_ID        0xD0   /* 칩 ID (BME280 = 0x60) */
#define BME280_REG_CTRL_HUM  0xF2
#define BME280_REG_CTRL_MEAS 0xF4
#define BME280_REG_CONFIG    0xF5
#define BME280_REG_CALIB00   0x88   /* 온도·기압 보정계수 시작 (26바이트) */
#define BME280_REG_CALIB26   0xE1   /* 습도 보정계수 시작 (7바이트) */
#define BME280_REG_DATA      0xF7   /* 측정 원시값 시작 (8바이트) */

/* -- 내부 상태(이 파일 안에서만 사용) -- */
static struct {
    uint16_t T1; int16_t T2, T3;
    uint16_t P1; int16_t P2, P3, P4, P5, P6, P7, P8, P9;
    uint8_t  H1; int16_t H2; uint8_t H3; int16_t H4, H5; int8_t H6;
} cal;
static double g_t_fine;             /* 온도 보정에서 계산 → 습도·기압 보정에 재사용 */

/* 보정계수(NVM)를 읽어 cal에 채움. 센서 고유값이므로 초기화 시 1회만 수행 */
static void bme280_read_calibration(int i2c_handle) {
    uint8_t t[26], h[7];
    lgI2cReadI2CBlockData(i2c_handle, BME280_REG_CALIB00, (char *)t, 26);
    lgI2cReadI2CBlockData(i2c_handle, BME280_REG_CALIB26, (char *)h, 7);

    cal.T1 = (uint16_t)(t[1] << 8 | t[0]);
    cal.T2 = (int16_t) (t[3] << 8 | t[2]);
    cal.T3 = (int16_t) (t[5] << 8 | t[4]);
    cal.P1 = (uint16_t)(t[7] << 8 | t[6]);
    cal.P2 = (int16_t) (t[9] << 8 | t[8]);
    cal.P3 = (int16_t) (t[11] << 8 | t[10]);
    cal.P4 = (int16_t) (t[13] << 8 | t[12]);
    cal.P5 = (int16_t) (t[15] << 8 | t[14]);
    cal.P6 = (int16_t) (t[17] << 8 | t[16]);
    cal.P7 = (int16_t) (t[19] << 8 | t[18]);
    cal.P8 = (int16_t) (t[21] << 8 | t[20]);
    cal.P9 = (int16_t) (t[23] << 8 | t[22]);
    cal.H1 = t[25];
    cal.H2 = (int16_t)(h[1] << 8 | h[0]);
    cal.H3 = h[2];
    cal.H4 = (int16_t)((h[3] << 4) | (h[4] & 0x0F));
    cal.H5 = (int16_t)((h[5] << 4) | (h[4] >> 4));
    cal.H6 = (int8_t)h[6];
}

/* 온도 보정 - g_t_fine 갱신(습도·기압 보정에서 재사용하므로 반드시 먼저 호출) */
static double compensate_T(int32_t adc_T) {
    double v1 = ((double)adc_T / 16384.0 - (double)cal.T1 / 1024.0) * (double)cal.T2;
    double v2 = ((double)adc_T / 131072.0 - (double)cal.T1 / 8192.0);
    v2 = v2 * v2 * (double)cal.T3;
    g_t_fine = v1 + v2;
    return g_t_fine / 5120.0;                        /* °C */
}

static double compensate_P(int32_t adc_P) {
    double v1 = g_t_fine / 2.0 - 64000.0;
    double v2 = v1 * v1 * (double)cal.P6 / 32768.0;
    v2 = v2 + v1 * (double)cal.P5 * 2.0;
    v2 = v2 / 4.0 + (double)cal.P4 * 65536.0;
    v1 = ((double)cal.P3 * v1 * v1 / 524288.0 + (double)cal.P2 * v1) / 524288.0;
    v1 = (1.0 + v1 / 32768.0) * (double)cal.P1;
    if (v1 == 0.0)
        return 0.0;                                   /* 0으로 나누기 방지 */
    double p = 1048576.0 - (double)adc_P;
    p = (p - v2 / 4096.0) * 6250.0 / v1;
    v1 = (double)cal.P9 * p * p / 2147483648.0;
    v2 = p * (double)cal.P8 / 32768.0;
    p = p + (v1 + v2 + (double)cal.P7) / 16.0;
    return p / 100.0;                                 /* hPa */
}

static double compensate_H(int32_t adc_H) {
    double h = g_t_fine - 76800.0;
    h = ((double)adc_H - ((double)cal.H4 * 64.0 + (double)cal.H5 / 16384.0 * h)) *
        ((double)cal.H2 / 65536.0 * (1.0 + (double)cal.H6 / 67108864.0 * h *
         (1.0 + (double)cal.H3 / 67108864.0 * h)));
    h = h * (1.0 - (double)cal.H1 * h / 524288.0);
    if (h > 100.0)
        h = 100.0;
    else if (h < 0.0)
        h = 0.0;
    return h;                                         /* % */
}

int bme280_init(int i2c_handle) {
    if (lgI2cReadByteData(i2c_handle, BME280_REG_ID) != 0x60) {  /* 칩 ID가 아니면 미지원 모델 */
        return HAL_ERR_UNSUPPORTED_MODEL;
    }
    bme280_read_calibration(i2c_handle);
    lgI2cWriteByteData(i2c_handle, BME280_REG_CTRL_HUM,  0x01);  /* 습도 oversampling x1 */
    lgI2cWriteByteData(i2c_handle, BME280_REG_CTRL_MEAS, 0x27);  /* 온도·기압 x1, normal 모드 */
    lgI2cWriteByteData(i2c_handle, BME280_REG_CONFIG,    0xA0);  /* standby 1s, 필터 off */
    return MW_OK;
}

int bme280_read(int i2c_handle, double *temperature, double *pressure, double *humidity) {
    uint8_t d[8];                                         /* 원시값 8바이트 버스트 읽기 */
    if (lgI2cReadI2CBlockData(i2c_handle, BME280_REG_DATA, (char *)d, 8) < 0)
        return HAL_ERR_I2C;                                /* I2C 통신 오류 */

    int32_t adc_P = (int32_t)(((uint32_t)d[0] << 12) | ((uint32_t)d[1] << 4) | (d[2] >> 4));
    int32_t adc_T = (int32_t)(((uint32_t)d[3] << 12) | ((uint32_t)d[4] << 4) | (d[5] >> 4));
    int32_t adc_H = (int32_t)(((uint32_t)d[6] << 8)  |  (uint32_t)d[7]);

    *temperature = compensate_T(adc_T);        /* 온도 먼저 → t_fine 확정 */
    *pressure    = compensate_P(adc_P);
    *humidity    = compensate_H(adc_H);
    return MW_OK;
}
