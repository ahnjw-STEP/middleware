/* event.c - Event Manager 구현 */
#include "event.h"
#include <pthread.h>
#include <signal.h>
#include <string.h>
#include <time.h>

#define EVT_QUEUE_SIZE  64   /* 링 버퍼 칸 수 - 동적 할당을 쓰지 않고 컴파일 시점에 고정 */
#define EVT_TIMER_MAX    4   /* 등록 가능한 주기 이벤트 개수 */

/* -- 내부 상태 (이 파일 안에서만 사용) -- */
static Event_t g_queue[EVT_QUEUE_SIZE];   /* 링 버퍼 본체 */
static int     g_head  = 0;               /* 다음에 꺼낼 칸 */
static int     g_tail  = 0;               /* 다음에 넣을 칸 */
static int     g_count = 0;               /* 현재 들어 있는 이벤트 수 */

/* 여러 생산자와 하나의 소비자가 같은 링 버퍼를 접근하므로 잠금이 필요하다.
   조건 변수는 "큐가 비어 있는 동안 소비자는 블럭되고, 이벤트가 들어오면 깨우는" 역할을 한다. */
static pthread_mutex_t g_lock      = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  g_not_empty = PTHREAD_COND_INITIALIZER;

static EventHandler_t g_handlers[EVT_TYPE_COUNT];   /* 이벤트 종류별 핸들러 테이블 */

/* 주기 이벤트 표. next_due는 다음 발생 예정 시각(Unix 초) */
static struct {
    int         valid;
    EventType_t type;
    int         period_sec;
    time_t      next_due;
} g_timers[EVT_TIMER_MAX];

static volatile sig_atomic_t g_running = 0;   /* 이벤트 루프 실행 여부(시그널 핸들러가 내림) */
static int       g_initialized = 0;
static pthread_t g_timer_tid;

int evt_init(void) {
    memset(g_handlers, 0, sizeof(g_handlers));
    memset(g_timers,   0, sizeof(g_timers));
    g_head = g_tail = g_count = 0;
    g_initialized = 1;
    return MW_OK;
}

int evt_register_handler(EventType_t type, EventHandler_t handler) {
    if (handler == NULL || (int)type < 0 || (int)type >= EVT_TYPE_COUNT)
        return MW_ERR_INVALID_PARAM;
    if (!g_initialized)
        return MW_ERR_NOT_INITIALIZED;
    g_handlers[type] = handler;   /* 종류당 하나 - 다시 등록하면 덮어씀 */
    return MW_OK;
}

int evt_timer_add(EventType_t type, int period_sec) {
    if ((int)type < 0 || (int)type >= EVT_TYPE_COUNT || period_sec <= 0)
        return MW_ERR_INVALID_PARAM;
    if (!g_initialized)
        return MW_ERR_NOT_INITIALIZED;

    for (int i = 0; i < EVT_TIMER_MAX; i++) {
        if (g_timers[i].valid)
            continue;
        g_timers[i].valid       = 1;
        g_timers[i].type       = type;
        g_timers[i].period_sec = period_sec;
        g_timers[i].next_due   = 0;   /* 실제 기준 시각은 evt_run()이 세운다 */
        return MW_OK;
    }
    return EVT_ERR_TIMER_FULL;
}

int evt_post(const Event_t *ev) {
    if (ev == NULL || (int)ev->type < 0 || (int)ev->type >= EVT_TYPE_COUNT)
        return MW_ERR_INVALID_PARAM;
    if (!g_initialized)
        return MW_ERR_NOT_INITIALIZED;

    pthread_mutex_lock(&g_lock);

    if (g_count >= EVT_QUEUE_SIZE) {
        /* 이미 대기 중인 이벤트는 아직 처리되지 않은 유효한 요청이므로 밀어내지 않고,
           새로 들어온 이벤트를 거부한다. 버려졌다는 사실은 반환값으로 호출자에게 알린다. */
        pthread_mutex_unlock(&g_lock);
        return EVT_ERR_QUEUE_FULL;
    }

    g_queue[g_tail] = *ev;                      /* 값 복사 - 생산자의 지역 변수를 그대로 넘겨도 안전 */
    g_tail = (g_tail + 1) % EVT_QUEUE_SIZE;     /* 끝에 닿으면 앞으로 되돌아가는 원형 구조 */
    g_count++;

    pthread_cond_signal(&g_not_empty);          /* 큐가 비어 잠들어 있던 소비자를 깨움 */
    pthread_mutex_unlock(&g_lock);
    return MW_OK;
}

/* 주기 이벤트 발생 스레드 : 1초마다 깨어나 만기된 타이머의 이벤트를 큐에 넣는다 */
static void *timer_thread(void *arg) {
    (void)arg;
    while (g_running) {
        struct timespec tick = { 1, 0 };   /* 1초 */
        nanosleep(&tick, NULL);

        time_t now = time(NULL);
        for (int i = 0; i < EVT_TIMER_MAX; i++) {
            if (!g_timers[i].valid)
                continue;
            if (now < g_timers[i].next_due)
                continue;
            Event_t ev;
            memset(&ev, 0, sizeof(ev));
            ev.type = g_timers[i].type;
            evt_post(&ev);   /* 큐가 가득 차 실패해도 다음 주기에 다시 발생하므로 그대로 진행 */
            g_timers[i].next_due = now + g_timers[i].period_sec;
        }
    }
    return NULL;
}

int evt_run(void) {
    if (!g_initialized)
        return MW_ERR_NOT_INITIALIZED;

    g_running = 1;

    /* 타이머의 첫 발생 시각을 지금 기준으로 세운다(등록은 이 함수 호출 전에 끝나 있어야 함) */
    time_t now = time(NULL);
    for (int i = 0; i < EVT_TIMER_MAX; i++) {
        if (g_timers[i].valid)
            g_timers[i].next_due = now + g_timers[i].period_sec;
    }

    if (pthread_create(&g_timer_tid, NULL, timer_thread, NULL) != 0) {
        g_running = 0;
        return EVT_ERR_THREAD;
    }

    while (g_running) {
        Event_t ev;
        int got = 0;

        pthread_mutex_lock(&g_lock);
        while (g_count == 0 && g_running) {
            /* 무한 대기 대신 시한 대기를 쓴다 - 종료 플래그를 주기적으로 확인해야
               시그널로 종료를 요청했을 때 큐가 비어 있어도 루프를 빠져나올 수 있다. */
            struct timespec until;
            clock_gettime(CLOCK_REALTIME, &until);
            until.tv_nsec += 200 * 1000 * 1000;   /* 200ms */
            if (until.tv_nsec >= 1000000000L) {
                until.tv_nsec -= 1000000000L;
                until.tv_sec  += 1;
            }
            pthread_cond_timedwait(&g_not_empty, &g_lock, &until);
        }
        if (g_count > 0) {
            ev = g_queue[g_head];
            g_head = (g_head + 1) % EVT_QUEUE_SIZE;
            g_count--;
            got = 1;
        }
        pthread_mutex_unlock(&g_lock);

        /* 핸들러 호출은 잠금을 푼 뒤에 한다 - 핸들러가 오래 걸려도 생산자가 큐에 넣는 것을
           막지 않는다. 소비자가 하나뿐이므로 핸들러들은 서로 겹쳐 실행되지 않는다. */
        if (got && g_handlers[ev.type] != NULL)
            g_handlers[ev.type](&ev);
    }

    pthread_join(g_timer_tid, NULL);
    return MW_OK;
}

/* 종료 요청. 플래그 대입 하나뿐이므로 시그널 핸들러에서 호출해도 안전하다. */
void evt_stop(void) {
    g_running = 0;
}

void evt_cleanup(void) {
    pthread_mutex_lock(&g_lock);
    g_head = g_tail = g_count = 0;
    pthread_mutex_unlock(&g_lock);
    memset(g_handlers, 0, sizeof(g_handlers));
    memset(g_timers,   0, sizeof(g_timers));
    g_initialized = 0;
}
