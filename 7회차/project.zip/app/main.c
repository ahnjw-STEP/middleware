/* main.c - 이벤트 기반 게이트웨이 (이벤트 큐 + 이벤트 핸들러) */
#include "hal.h"
#include "protocol.h"
#include "storeforward.h"
#include "event.h"
#include <stdio.h>
#include <signal.h>
#include <string.h>

/* 데모용 고정 주기(초). 데모 프로그램이므로 상수로 고정 - 실제 배포 환경의 측정 주기는
   gateway.conf의 read_period를, 재전송 시도 주기는 운영 정책을 따라 설정할 수 있다
   (이 회차의 구현 범위 밖. 값을 설정 파일과 실제로 연동하는 것은 이후 회차 과제). */
#define SENSOR_TICK_PERIOD_SEC   10
#define FORWARD_TICK_PERIOD_SEC  30

/* -- 생산자 쪽 : 통신 스레드에서 호출되는 얇은 어댑터 --
   이 함수는 통신 라이브러리의 네트워크 스레드에서 호출된다. GPIO 제어처럼 시간이 걸리는
   일을 여기서 직접 하면 그 사이 다른 메시지를 받을 수 없으므로, 이벤트만 큐에 넣고 즉시
   반환한다. 실제 처리는 이벤트 루프가 맡는다. */
static void on_command_received(const CommandData_t *cmd) {
    Event_t ev;
    ev.type = EVT_COMMAND;
    ev.cmd  = *cmd;
    if (evt_post(&ev) != MW_OK)
        fprintf(stderr, "[WARN] event queue full - command dropped\n");
}

/* -- 소비자 쪽 : 이벤트 루프 스레드에서 실행되는 핸들러들 -- */

/* 측정 주기 도래 : 센서를 읽어 발행 */
static void handle_sensor_tick(const Event_t *ev) {
    (void)ev;
    THPSensorData_t data;
    if (hal_thp_sensor_read("ENV-01", &data) != MW_OK)
        return;
    int r = protocol_publish_thp_sensor(&data);
    if (r == MW_OK)
        printf("[PUB] T=%.2f H=%.1f P=%.1f published\n",
               data.temperature, data.humidity, data.pressure);
    else if (r == PROTO_ERR_PUBLISH_STORED)
        printf("[WARN] publish failed, stored to DB (보존됨)\n");
    else if (r == PROTO_ERR_PUBLISH_LOST)
        fprintf(stderr, "[ERROR] publish/store 모두 실패 (데이터 손실)\n");
}

/* 제어 명령 : 액추에이터 제어. 이벤트 루프 스레드 한 곳에서만 HAL을 만진다. */
static void handle_command(const Event_t *ev) {
    printf("[CMD] %s <- %d\n", ev->cmd.actuator_id, ev->cmd.value);
    hal_actuator_write(ev->cmd.actuator_id, ev->cmd.value);
}

/* 재전송 시도 시점 도래 : 저장돼 있던 미전송 데이터를 다시 발행하고 성공분을 삭제 */
static void handle_forward_tick(const Event_t *ev) {
    (void)ev;
    THPSensorData_t pending[16];
    int n = snf_get_pending_thp(pending, 16);
    for (int i = 0; i < n; i++) {
        if (protocol_publish_thp_sensor(&pending[i]) == MW_OK) {
            snf_delete_pending(pending[i].sensor_id, pending[i].timestamp);
            printf("[FORWARD] resent & deleted (ts=%lld)\n",
                   (long long)pending[i].timestamp);
        }
    }
}

/* SIGINT(Ctrl+C) 처리 : 플래그를 내리는 evt_stop()만 호출한다.
   시그널 핸들러에서 printf나 자원 해제를 직접 하면 안전하지 않으므로, 정리 작업은
   이벤트 루프가 정상적으로 반환된 뒤 main()에서 수행한다. */
static void on_sigint(int signo) {
    (void)signo;
    evt_stop();
}

int main(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_sigint;
    sigaction(SIGINT, &sa, NULL);

    if (hal_init("gateway.conf") != MW_OK) {
        fprintf(stderr, "hal_init 실패\n");
        return 1;
    }
    if (protocol_init("gateway.conf") != MW_OK) {
        fprintf(stderr, "protocol_init 실패\n");
        hal_cleanup();
        return 1;
    }
    evt_init();   /* 반환값이 항상 MW_OK이므로 별도 오류 처리를 두지 않음 */

    /* 이벤트 종류별 핸들러 등록 */
    evt_register_handler(EVT_SENSOR_TICK,  handle_sensor_tick);
    evt_register_handler(EVT_COMMAND,      handle_command);
    evt_register_handler(EVT_FORWARD_TICK, handle_forward_tick);

    /* 명령 수신 경로 연결 : 통신 모듈은 큐에 넣는 어댑터만 알면 된다 */
    protocol_subscribe_command(on_command_received);

    /* 주기 이벤트 등록 */
    evt_timer_add(EVT_SENSOR_TICK,  SENSOR_TICK_PERIOD_SEC);
    evt_timer_add(EVT_FORWARD_TICK, FORWARD_TICK_PERIOD_SEC);

    printf("[RUN] 이벤트 루프 시작 (측정 %d초, 재전송 %d초 주기). 종료는 Ctrl+C\n",
           SENSOR_TICK_PERIOD_SEC, FORWARD_TICK_PERIOD_SEC);

    evt_run();   /* 이 지점에서 이벤트 루프가 돌고, evt_stop() 후에 반환된다 */

    printf("\n[EXIT] 이벤트 루프 종료 - 자원 정리\n");
    evt_cleanup();
    protocol_cleanup();
    hal_cleanup();
    return 0;
}
