/* event.h - Event Manager 인터페이스 (이벤트 큐와 이벤트 핸들러 관리) */
#ifndef EVENT_H
#define EVENT_H

#include "middleware_types.h"    /* CommandData_t */
#include "middleware_errors.h"   /* MW_OK, MW_ERR_*, EVT_ERR_* */

/* 이벤트 종류. 새 종류는 EVT_TYPE_COUNT 앞에 추가한다(핸들러 테이블 크기가 함께 늘어남). */
typedef enum {
    EVT_SENSOR_TICK = 0,   /* 센서 측정 주기 도래 */
    EVT_COMMAND,           /* 관제서버 제어 명령 수신 */
    EVT_FORWARD_TICK,      /* 미전송 데이터 재전송 시도 시점 도래 */
    EVT_TYPE_COUNT         /* 종류 개수(값이 아니라 개수를 나타내는 항목) */
} EventType_t;

/* 큐에 담기는 이벤트 한 건. 큐가 값을 복사해 보관하므로 생산자의 지역 변수를 그대로 넘겨도 된다. */
typedef struct {
    EventType_t   type;
    CommandData_t cmd;   /* type == EVT_COMMAND일 때만 유효 */
} Event_t;

/* 이벤트 핸들러 원형의 타입 정의 */
typedef void (*EventHandler_t)(const Event_t *ev);

/* 큐·핸들러 테이블·타이머 테이블을 초기화 */
int  evt_init(void);

/* 이벤트 종류별 핸들러 등록(종류당 하나). evt_run() 호출 전에 등록 */
int  evt_register_handler(EventType_t type, EventHandler_t handler);

/* 주기 이벤트 등록(초 단위). evt_run() 호출 전에 등록 */
int  evt_timer_add(EventType_t type, int period_sec);

/* 이벤트를 큐에 넣고 즉시 반환. 어느 스레드에서 호출해도 안전 */
int  evt_post(const Event_t *ev);

/* 호출한 스레드를 이벤트 루프로 전환. evt_stop() 호출 시 반환 */
int  evt_run(void);

/* 이벤트 루프 종료 요청. 플래그만 세우므로 시그널 핸들러에서 호출해도 안전 */
void evt_stop(void);

/* 큐·타이머 자원 해제 */
void evt_cleanup(void);

#endif /* EVENT_H */
